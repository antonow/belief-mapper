[belief-mapper](https://beliefmapper.herokuapp.com)
=============

Belief Mapper is an interactive tool that allows you to create a visual map of your beliefs. Find out what your beliefs are by answering questions. Belief Mapper keeps track of your beliefs and shows trends in how people share related beliefs.

Visit [beliefmapper.herokuapp.com](https://beliefmapper.herokuapp.com) to try it for yourself.
