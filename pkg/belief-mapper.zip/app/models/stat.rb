class Stat < ActiveRecord::Base
	has_many :belief_stats
end
